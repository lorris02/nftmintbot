# 🤖 NFT Mint Bot

Multi-chain NFT minting Telegram bot — ETH, Base, Solana (extendable).

## Setup

### 1. Install dependencies
```bash
npm install
```

### 2. Configure environment
```bash
cp .env.example .env
```
Edit `.env` and add your:
- `BOT_TOKEN` — get from [@BotFather](https://t.me/BotFather) on Telegram
- RPC endpoints (free public ones are pre-filled)
- `OPENSEA_API_KEY` (optional, for floor prices without rate limits)

### 3. Create data folder
```bash
mkdir -p data/wallets
```

### 4. Run
```bash
# Production
npm start

# Development (auto-restart)
npm run dev
```

---

## Commands

| Command | Description |
|---|---|
| `/start` | Welcome screen + keyboard |
| `/genwallets <count> <chain> <label>` | Generate wallets (max 500) |
| `/addwallet <chain> <privatekey> [label]` | Import existing wallet |
| `/wallets` | List all wallets |
| `/balance [chain]` | Check balances |
| `/fundwallets <chain> <amount>` | Distribute gas to all wallets |
| `/mint <chain> <contract> <qty> [maxGwei] [label]` | Manual mint |
| `/batchmint <chain> <contract> <qty> [maxGwei]` | Mint from all wallets |
| `/schedulemint <chain> <contract> <qty> <date> <time> [maxGwei]` | Schedule a mint |
| `/monitor <chain> <contract> [autoMintQty] [maxGwei]` | Watch contract + optional auto-mint |
| `/whitelist <chain> <contract> [address]` | Check whitelist status |
| `/gas [chain] [alertGwei]` | Gas prices + optional alert |
| `/floor <chain> <collection>` | NFT floor price |
| `/status` | Active monitors + scheduled mints |
| `/cancel [id]` | Cancel task(s) |

---

## Hosting (VPS)

Recommended: **Contabo** (~$5/mo) or **Hetzner** (~$4/mo)

```bash
# Keep running with PM2
npm install -g pm2
pm2 start src/index.js --name nft-bot
pm2 save
pm2 startup
```

---

## Adding More Chains

In `src/utils/providers.js`, add a new case:
```js
case 'polygon':
  return new ethers.JsonRpcProvider('https://polygon-rpc.com');
```

Then add to wallet generator in `src/commands/wallet.js` supported chains array.

---

## ⚠️ Security

- Never share your `.env` file
- Wallet private keys are stored locally in `data/wallets/`
- Keep your VPS firewall locked down
- Run behind a VPN when uploading/deploying
