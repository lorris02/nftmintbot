#!/bin/bash

echo "🤖 NFT Mint Bot — Setup"
echo "━━━━━━━━━━━━━━━━━━━━━━━"

# Check Node.js
if ! command -v node &> /dev/null; then
  echo "❌ Node.js not found. Install it from https://nodejs.org (v18+ recommended)"
  exit 1
fi
echo "✅ Node.js $(node -v) found"

# Check npm
if ! command -v npm &> /dev/null; then
  echo "❌ npm not found."
  exit 1
fi
echo "✅ npm $(npm -v) found"

# Install dependencies
echo ""
echo "📦 Installing dependencies..."
npm install

# Create data folder
mkdir -p data/wallets
echo "✅ data/wallets folder created"

# Setup .env
if [ ! -f .env ]; then
  cp .env.example .env
  echo ""
  echo "📝 .env file created from template"
  echo ""
  echo "⚠️  IMPORTANT: Open .env and add your BOT_TOKEN before starting!"
  echo "   Get your token from @BotFather on Telegram"
else
  echo "✅ .env already exists"
fi

# Check PM2 for production
echo ""
read -p "Install PM2 for 24/7 hosting? (y/n): " install_pm2
if [ "$install_pm2" = "y" ]; then
  npm install -g pm2
  echo "✅ PM2 installed"
  echo ""
  echo "To run with PM2:"
  echo "  pm2 start src/index.js --name nft-bot"
  echo "  pm2 save"
  echo "  pm2 startup"
fi

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━"
echo "✅ Setup complete!"
echo ""
echo "Next steps:"
echo "  1. Add your BOT_TOKEN to .env"
echo "  2. Run: npm start"
echo "  3. Open Telegram and message your bot /start"
echo "━━━━━━━━━━━━━━━━━━━━━━━"
