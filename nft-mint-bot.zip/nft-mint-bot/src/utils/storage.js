const path = require('path');
const fs = require('fs');

// Railway Volume mounts to /data by default
// Falls back to local ./data folder for development
const DATA_ROOT = process.env.RAILWAY_VOLUME_MOUNT_PATH
  ? path.join(process.env.RAILWAY_VOLUME_MOUNT_PATH, 'wallets')
  : path.join(__dirname, '../../data/wallets');

// Make sure the folder exists on startup
if (!fs.existsSync(DATA_ROOT)) {
  fs.mkdirSync(DATA_ROOT, { recursive: true });
}

module.exports = { DATA_ROOT };
