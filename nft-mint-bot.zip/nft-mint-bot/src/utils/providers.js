const { ethers } = require('ethers');

const getProvider = (chain) => {
  switch (chain.toLowerCase()) {
    case 'eth':
      return new ethers.JsonRpcProvider(process.env.ETH_RPC || 'https://eth.llamarpc.com');
    case 'base':
      return new ethers.JsonRpcProvider(process.env.BASE_RPC || 'https://mainnet.base.org');
    default:
      throw new Error(`Unknown chain: ${chain}`);
  }
};

const getChainId = (chain) => {
  switch (chain.toLowerCase()) {
    case 'eth': return 1;
    case 'base': return 8453;
    default: throw new Error(`Unknown chain: ${chain}`);
  }
};

module.exports = { getProvider, getChainId };
