require('dotenv').config();
const { Telegraf, Markup } = require('telegraf');
const bot = new Telegraf(process.env.BOT_TOKEN);

// Import commands
const startCmd = require('./commands/start');
const walletCmd = require('./commands/wallet');
const mintCmd = require('./commands/mint');
const monitorCmd = require('./commands/monitor');
const gasCmd = require('./commands/gas');
const floorCmd = require('./commands/floor');

// Register commands
bot.command('start', startCmd);

// Wallet commands
bot.command('genwallets', walletCmd.genWallets);
bot.command('addwallet', walletCmd.addWallet);
bot.command('wallets', walletCmd.listWallets);
bot.command('balance', walletCmd.checkBalance);
bot.command('fundwallets', walletCmd.fundWallets);

// Mint commands
bot.command('mint', mintCmd.manualMint);
bot.command('batchmint', mintCmd.batchMint);
bot.command('schedulemint', mintCmd.scheduleMint);

// Monitor commands
bot.command('monitor', monitorCmd.startMonitor);
bot.command('whitelist', monitorCmd.checkWhitelist);
bot.command('status', monitorCmd.getStatus);
bot.command('cancel', monitorCmd.cancelTask);

// Gas & floor commands
bot.command('gas', gasCmd.getGas);
bot.command('floor', floorCmd.getFloor);

// Handle callback queries (inline buttons)
bot.on('callback_query', async (ctx) => {
  const data = ctx.callbackQuery.data;

  if (data.startsWith('chain_')) {
    const chain = data.replace('chain_', '');
    ctx.session = ctx.session || {};
    ctx.session.selectedChain = chain;
    await ctx.answerCbQuery(`✅ Chain set to ${chain.toUpperCase()}`);
    await ctx.editMessageText(`✅ *Chain selected:* \`${chain.toUpperCase()}\`\n\nNow use your commands.`, { parse_mode: 'Markdown' });
  }

  if (data.startsWith('confirm_')) {
    await ctx.answerCbQuery('Confirmed!');
  }

  if (data === 'cancel') {
    await ctx.answerCbQuery('Cancelled');
    await ctx.editMessageText('❌ Action cancelled.');
  }
});

// Error handler
bot.catch((err, ctx) => {
  console.error(`Error for ${ctx.updateType}:`, err);
  ctx.reply('⚠️ Something went wrong. Try again.');
});

// Launch
bot.launch().then(() => {
  console.log('🤖 NFT Mint Bot is live!');
});

// Graceful stop
process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));
