const { ethers } = require('ethers');
const { getProvider } = require('../utils/providers');
const fs = require('fs');
const path = require('path');

global.activeMonitors = global.activeMonitors || {};

const { DATA_ROOT: WALLETS_DIR } = require('../utils/storage');
const loadWallets = (userId) => {
  const file = path.join(WALLETS_DIR, `${userId}.json`);
  if (!fs.existsSync(file)) return [];
  return JSON.parse(fs.readFileSync(file, 'utf8'));
};

// Minimal ABI to detect mint state
const CONTRACT_ABI = [
  'function paused() view returns (bool)',
  'function mintingEnabled() view returns (bool)',
  'function saleIsActive() view returns (bool)',
  'function publicSaleActive() view returns (bool)',
  'function totalSupply() view returns (uint256)',
  'function maxSupply() view returns (uint256)',
  'function price() view returns (uint256)',
  'function mintPrice() view returns (uint256)',
];

const WHITELIST_ABI = [
  'function isWhitelisted(address) view returns (bool)',
  'function whitelist(address) view returns (bool)',
  'function allowlist(address) view returns (bool)',
];

// /monitor <chain> <contract> [auto_mint_qty] [maxGasGwei]
const startMonitor = async (ctx) => {
  const args = ctx.message.text.split(' ').slice(1);
  if (args.length < 2) {
    return ctx.reply(
      '📋 *Usage:*\n`/monitor <chain> <contract> [auto_mint_qty] [maxGasGwei]`\n\n*Examples:*\n`/monitor eth 0xabc...123` — alert only\n`/monitor eth 0xabc...123 1 30` — alert + auto-mint 1 per wallet at max 30 gwei',
      { parse_mode: 'Markdown' }
    );
  }

  const [chain, contractAddress, autoMintQty, maxGasGwei] = args;
  const userId = ctx.from.id.toString();
  const monitorId = `${userId}_${contractAddress.slice(0, 8)}_${Date.now()}`;

  const autoMint = autoMintQty ? parseInt(autoMintQty) : null;

  await ctx.reply(
    `👀 *Monitor Started*\n\nContract: \`${contractAddress}\`\nChain: \`${chain.toUpperCase()}\`\nAuto-mint: ${autoMint ? `\`${autoMint} per wallet\`` : '❌ (alert only)'}\nID: \`${monitorId}\``,
    { parse_mode: 'Markdown' }
  );

  const provider = getProvider(chain);

  // Poll every 5 seconds for mint state changes
  let lastState = null;
  const interval = setInterval(async () => {
    try {
      const contract = new ethers.Contract(contractAddress, CONTRACT_ABI, provider);
      let isLive = false;

      // Try multiple common state checks
      const checks = ['saleIsActive', 'publicSaleActive', 'mintingEnabled'];
      for (const fn of checks) {
        try {
          const result = await contract[fn]();
          isLive = result;
          break;
        } catch (_) { continue; }
      }

      // Also check paused()
      let paused = false;
      try { paused = await contract.paused(); } catch (_) {}
      if (paused) isLive = false;

      // State changed to LIVE
      if (isLive && lastState !== true) {
        lastState = true;

        let mintPrice = '?';
        try {
          const price = await contract.price().catch(() => contract.mintPrice());
          mintPrice = ethers.formatEther(price) + ` ${chain.toUpperCase()}`;
        } catch (_) {}

        await ctx.reply(
          `🚨 *MINT IS LIVE!*\n\nContract: \`${contractAddress}\`\nChain: \`${chain.toUpperCase()}\`\nPrice: \`${mintPrice}\`\n\n${autoMint ? '🤖 Auto-minting now...' : '⚡ Use /batchmint to mint now!'}`,
          { parse_mode: 'Markdown' }
        );

        // Auto-mint if configured
        if (autoMint) {
          const wallets = loadWallets(userId).filter(w => w.chain === chain);
          if (wallets.length > 0) {
            const { batchMint } = require('./mint');
            ctx.message = { ...ctx.message, text: `/batchmint ${chain} ${contractAddress} ${autoMint}${maxGasGwei ? ` ${maxGasGwei}` : ''}` };
            await batchMint(ctx);
          }
        }
      }

      // State changed to INACTIVE
      if (!isLive && lastState === true) {
        lastState = false;
        await ctx.reply(`⏸️ Mint appears to be *paused/ended* for \`${contractAddress.slice(0, 8)}...\``, { parse_mode: 'Markdown' });
      }

      if (lastState === null) lastState = isLive;

    } catch (e) {
      // Contract might not be deployed yet, keep polling silently
    }
  }, 5000);

  global.activeMonitors[monitorId] = {
    interval,
    contractAddress,
    chain,
    autoMint,
    userId,
    startedAt: new Date().toISOString(),
  };
};

// /whitelist <chain> <contract> [walletAddress]
const checkWhitelist = async (ctx) => {
  const args = ctx.message.text.split(' ').slice(1);
  if (args.length < 2) {
    return ctx.reply(
      '📋 *Usage:*\n`/whitelist <chain> <contract> [walletAddress]`\n\nIf walletAddress is omitted, checks all your wallets.',
      { parse_mode: 'Markdown' }
    );
  }

  const [chain, contractAddress, specificAddress] = args;
  const userId = ctx.from.id.toString();

  let addressesToCheck = [];
  if (specificAddress) {
    addressesToCheck = [{ label: specificAddress, address: specificAddress }];
  } else {
    const wallets = loadWallets(userId).filter(w => w.chain === chain);
    if (wallets.length === 0) return ctx.reply(`No ${chain.toUpperCase()} wallets found.`);
    addressesToCheck = wallets;
  }

  await ctx.reply(`⏳ Checking whitelist for ${addressesToCheck.length} address(es)...`);

  const provider = getProvider(chain);
  const contract = new ethers.Contract(contractAddress, WHITELIST_ABI, provider);

  let msg = `📋 *Whitelist Check*\n\nContract: \`${contractAddress.slice(0, 8)}...\`\n━━━━━━━━━━━━━━━\n\n`;
  let whitelisted = 0;

  for (const w of addressesToCheck) {
    let status = '❓';
    const fns = ['isWhitelisted', 'whitelist', 'allowlist'];
    for (const fn of fns) {
      try {
        const result = await contract[fn](w.address);
        status = result ? '✅' : '❌';
        if (result) whitelisted++;
        break;
      } catch (_) { continue; }
    }
    msg += `${status} \`${w.label || w.address}\`\n`;
  }

  msg += `\n✅ Whitelisted: *${whitelisted}/${addressesToCheck.length}*`;
  await ctx.reply(msg, { parse_mode: 'Markdown' });
};

// /status
const getStatus = async (ctx) => {
  const userId = ctx.from.id.toString();

  const monitors = Object.entries(global.activeMonitors || {})
    .filter(([_, m]) => m.userId === userId);

  const scheduled = Object.entries(global.scheduledMints || {})
    .filter(([_, m]) => m.userId === userId);

  if (monitors.length === 0 && scheduled.length === 0) {
    return ctx.reply('No active monitors or scheduled mints.\n\nUse /monitor to start watching a contract.');
  }

  let msg = `📊 *Active Tasks*\n━━━━━━━━━━━━━━━\n\n`;

  if (monitors.length > 0) {
    msg += `*👀 Monitors (${monitors.length})*\n`;
    monitors.forEach(([id, m]) => {
      msg += `• \`${m.contractAddress.slice(0, 8)}...\` [${m.chain.toUpperCase()}]${m.autoMint ? ` — auto-mint ${m.autoMint}` : ''}\n  ID: \`${id}\`\n`;
    });
    msg += '\n';
  }

  if (scheduled.length > 0) {
    msg += `*⏰ Scheduled Mints (${scheduled.length})*\n`;
    scheduled.forEach(([id, m]) => {
      msg += `• \`${m.contractAddress.slice(0, 8)}...\` [${m.chain.toUpperCase()}] at \`${m.mintTime.toUTCString()}\`\n  ID: \`${id}\`\n`;
    });
  }

  msg += '\nUse `/cancel <id>` to stop any task.';
  await ctx.reply(msg, { parse_mode: 'Markdown' });
};

// /cancel [id]
const cancelTask = async (ctx) => {
  const args = ctx.message.text.split(' ').slice(1);
  const taskId = args[0];
  const userId = ctx.from.id.toString();

  if (!taskId) {
    // Cancel all for this user
    let cancelled = 0;
    Object.entries(global.activeMonitors || {}).forEach(([id, m]) => {
      if (m.userId === userId) { clearInterval(m.interval); delete global.activeMonitors[id]; cancelled++; }
    });
    Object.entries(global.scheduledMints || {}).forEach(([id, m]) => {
      if (m.userId === userId) { clearTimeout(m.timeout); delete global.scheduledMints[id]; cancelled++; }
    });
    return ctx.reply(`✅ Cancelled *${cancelled}* task(s).`, { parse_mode: 'Markdown' });
  }

  if (global.activeMonitors[taskId]) {
    clearInterval(global.activeMonitors[taskId].interval);
    delete global.activeMonitors[taskId];
    return ctx.reply(`✅ Monitor \`${taskId}\` cancelled.`, { parse_mode: 'Markdown' });
  }

  if (global.scheduledMints[taskId]) {
    clearTimeout(global.scheduledMints[taskId].timeout);
    delete global.scheduledMints[taskId];
    return ctx.reply(`✅ Scheduled mint \`${taskId}\` cancelled.`, { parse_mode: 'Markdown' });
  }

  ctx.reply('❌ Task not found.');
};

module.exports = { startMonitor, checkWhitelist, getStatus, cancelTask };
