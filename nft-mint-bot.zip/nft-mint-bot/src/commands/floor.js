const https = require('https');

const fetchJSON = (url, headers = {}) => new Promise((resolve, reject) => {
  const options = { headers: { 'User-Agent': 'NFTBot/1.0', ...headers } };
  https.get(url, options, (res) => {
    let data = '';
    res.on('data', chunk => data += chunk);
    res.on('end', () => {
      try { resolve(JSON.parse(data)); }
      catch (e) { reject(e); }
    });
  }).on('error', reject);
});

// /floor <chain> <collection_slug_or_address>
// ETH/Base: OpenSea slug e.g. "boredapeyachtclub"
// SOL: Magic Eden symbol e.g. "degods"
const getFloor = async (ctx) => {
  const args = ctx.message.text.split(' ').slice(1);
  if (args.length < 2) {
    return ctx.reply(
      '📋 *Usage:*\n`/floor <chain> <collection>`\n\n*Examples:*\n`/floor eth boredapeyachtclub`\n`/floor sol degods`\n\nFor ETH/Base use OpenSea collection slug.\nFor SOL use Magic Eden collection symbol.',
      { parse_mode: 'Markdown' }
    );
  }

  const [chain, collection] = args;
  await ctx.reply(`⏳ Fetching floor for \`${collection}\`...`, { parse_mode: 'Markdown' });

  try {
    let msg = `🌊 *Floor Price*\n\nCollection: \`${collection}\`\nChain: \`${chain.toUpperCase()}\`\n━━━━━━━━━━━━━━━\n\n`;

    if (chain === 'eth' || chain === 'base') {
      // OpenSea API v2
      const apiKey = process.env.OPENSEA_API_KEY || '';
      const data = await fetchJSON(
        `https://api.opensea.io/api/v2/collections/${collection}/stats`,
        apiKey ? { 'X-API-KEY': apiKey } : {}
      );

      if (data.total) {
        const floor = data.total.floor_price || '?';
        const volume = data.total.volume?.toFixed(2) || '?';
        const sales = data.total.sales || '?';
        msg += `Floor: \`${floor} ETH\`\n`;
        msg += `Total Volume: \`${volume} ETH\`\n`;
        msg += `Total Sales: \`${sales}\`\n`;
        if (data.intervals?.[0]) {
          const d = data.intervals[0];
          msg += `\n*24h Stats:*\nVolume: \`${d.volume?.toFixed(4) || '?'} ETH\`\nSales: \`${d.sales || '?'}\`\n`;
        }
        msg += `\n🔗 [View on OpenSea](https://opensea.io/collection/${collection})`;
      } else {
        msg += '❌ Collection not found on OpenSea.';
      }

    } else if (chain === 'sol') {
      // Magic Eden API
      const data = await fetchJSON(`https://api-mainnet.magiceden.dev/v2/collections/${collection}/stats`);
      if (data.floorPrice !== undefined) {
        const floor = (data.floorPrice / 1e9).toFixed(3);
        const volume = data.volumeAll ? (data.volumeAll / 1e9).toFixed(2) : '?';
        const listed = data.listedCount || '?';
        msg += `Floor: \`${floor} SOL\`\n`;
        msg += `Total Volume: \`${volume} SOL\`\n`;
        msg += `Listed: \`${listed}\`\n`;
        msg += `\n🔗 [View on Magic Eden](https://magiceden.io/marketplace/${collection})`;
      } else {
        msg += '❌ Collection not found on Magic Eden.';
      }
    } else {
      msg += `❌ Floor tracking not supported for chain: ${chain}`;
    }

    await ctx.reply(msg, { parse_mode: 'Markdown', disable_web_page_preview: true });
  } catch (e) {
    ctx.reply(`❌ Failed to fetch floor: ${e.message}`);
  }
};

module.exports = { getFloor };
