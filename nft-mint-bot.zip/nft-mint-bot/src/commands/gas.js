const { ethers } = require('ethers');
const { getProvider } = require('../utils/providers');

global.gasAlerts = global.gasAlerts || {};

// /gas [chain] [alert_threshold_gwei]
const getGas = async (ctx) => {
  const args = ctx.message.text.split(' ').slice(1);
  const chain = args[0]?.toLowerCase() || 'eth';
  const alertThreshold = args[1] ? parseFloat(args[1]) : null;
  const userId = ctx.from.id.toString();

  try {
    const provider = getProvider(chain);
    const feeData = await provider.getFeeData();

    const baseFee = feeData.gasPrice ? parseFloat(ethers.formatUnits(feeData.gasPrice, 'gwei')).toFixed(2) : '?';
    const maxFee = feeData.maxFeePerGas ? parseFloat(ethers.formatUnits(feeData.maxFeePerGas, 'gwei')).toFixed(2) : '?';
    const priority = feeData.maxPriorityFeePerGas ? parseFloat(ethers.formatUnits(feeData.maxPriorityFeePerGas, 'gwei')).toFixed(2) : '?';

    let msg = `⛽ *Gas Prices — ${chain.toUpperCase()}*\n━━━━━━━━━━━━━━━\n\n`;
    msg += `Base Fee: \`${baseFee} gwei\`\n`;
    msg += `Max Fee: \`${maxFee} gwei\`\n`;
    msg += `Priority: \`${priority} gwei\`\n`;

    // Estimate mint cost
    const gasLimit = 150000;
    const costEth = feeData.gasPrice ? parseFloat(ethers.formatEther(feeData.gasPrice * BigInt(gasLimit))).toFixed(5) : '?';
    msg += `\n💸 Est. mint cost (~150k gas): \`${costEth} ${chain.toUpperCase()}\``;

    if (alertThreshold) {
      global.gasAlerts[userId] = { chain, threshold: alertThreshold, ctx };
      msg += `\n\n🔔 Alert set: will ping you when gas drops below \`${alertThreshold} gwei\``;

      // Start polling for gas alert
      if (global.gasAlerts[userId]?.interval) clearInterval(global.gasAlerts[userId].interval);
      const interval = setInterval(async () => {
        try {
          const p = getProvider(chain);
          const fd = await p.getFeeData();
          const current = parseFloat(ethers.formatUnits(fd.gasPrice, 'gwei'));
          if (current <= alertThreshold) {
            await ctx.reply(`🚨 *Gas Alert!*\n\n${chain.toUpperCase()} gas is now \`${current.toFixed(2)} gwei\` (below your threshold of \`${alertThreshold} gwei\`)\n\nNow's a good time to mint! ⚡`, { parse_mode: 'Markdown' });
            clearInterval(interval);
            delete global.gasAlerts[userId];
          }
        } catch (_) {}
      }, 30000); // check every 30s
      global.gasAlerts[userId].interval = interval;
    }

    await ctx.reply(msg, { parse_mode: 'Markdown' });
  } catch (e) {
    ctx.reply(`❌ Could not fetch gas for ${chain.toUpperCase()}: ${e.message}`);
  }
};

module.exports = { getGas };
