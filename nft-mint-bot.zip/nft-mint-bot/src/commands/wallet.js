const { Markup } = require('telegraf');
const { ethers } = require('ethers');
const { Keypair } = require('@solana/web3.js');
const bs58 = require('bs58');
const fs = require('fs');
const path = require('path');

const { DATA_ROOT: WALLETS_DIR } = require('../utils/storage');

const getWalletsFile = (userId) => path.join(WALLETS_DIR, `${userId}.json`);

const loadWallets = (userId) => {
  const file = getWalletsFile(userId);
  if (!fs.existsSync(file)) return [];
  return JSON.parse(fs.readFileSync(file, 'utf8'));
};

const saveWallets = (userId, wallets) => {
  fs.writeFileSync(getWalletsFile(userId), JSON.stringify(wallets, null, 2));
};

// /genwallets <count> <chain> <label>
// e.g. /genwallets 10 eth mywallet
const genWallets = async (ctx) => {
  const args = ctx.message.text.split(' ').slice(1);
  const count = parseInt(args[0]) || 1;
  const chain = (args[1] || 'eth').toLowerCase();
  const label = args[2] || 'wallet';

  if (count > 500) return ctx.reply('❌ Max 500 wallets at a time.');
  if (!['eth', 'base', 'sol'].includes(chain)) return ctx.reply('❌ Supported chains: eth, base, sol');

  await ctx.reply(`⏳ Generating ${count} ${chain.toUpperCase()} wallets...`);

  const userId = ctx.from.id.toString();
  const existing = loadWallets(userId);
  const generated = [];

  for (let i = 0; i < count; i++) {
    let wallet;
    if (chain === 'eth' || chain === 'base') {
      const w = ethers.Wallet.createRandom();
      wallet = {
        id: `${label}_${Date.now()}_${i}`,
        label: `${label}_${i + 1}`,
        chain,
        address: w.address,
        privateKey: w.privateKey,
        mnemonic: w.mnemonic?.phrase || null,
        createdAt: new Date().toISOString(),
      };
    } else if (chain === 'sol') {
      const kp = Keypair.generate();
      wallet = {
        id: `${label}_${Date.now()}_${i}`,
        label: `${label}_${i + 1}`,
        chain,
        address: kp.publicKey.toBase58(),
        privateKey: bs58.encode(kp.secretKey),
        createdAt: new Date().toISOString(),
      };
    }
    generated.push(wallet);
  }

  existing.push(...generated);
  saveWallets(userId, existing);

  // Export as text file if count > 5
  if (count > 5) {
    const exportLines = generated.map(w => `${w.label} | ${w.address} | ${w.privateKey}`).join('\n');
    const exportPath = path.join(WALLETS_DIR, `export_${userId}_${Date.now()}.txt`);
    fs.writeFileSync(exportPath, exportLines);

    await ctx.replyWithDocument({ source: exportPath, filename: `wallets_${chain}_${count}.txt` }, {
      caption: `✅ Generated *${count}* ${chain.toUpperCase()} wallets.\n\n⚠️ *Save this file securely and delete it after.*`,
      parse_mode: 'Markdown'
    });

    fs.unlinkSync(exportPath); // delete after sending
  } else {
    let msg = `✅ *Generated ${count} ${chain.toUpperCase()} wallet(s):*\n\n`;
    generated.forEach(w => {
      msg += `*${w.label}*\n\`${w.address}\`\n`;
    });
    msg += '\n🔐 Private keys saved locally.';
    await ctx.reply(msg, { parse_mode: 'Markdown' });
  }
};

// /addwallet <chain> <privatekey> <label>
const addWallet = async (ctx) => {
  const args = ctx.message.text.split(' ').slice(1);
  if (args.length < 2) return ctx.reply('Usage: /addwallet <chain> <privatekey> [label]\nExample: /addwallet eth 0xabc... mywallet');

  const chain = args[0].toLowerCase();
  const privateKey = args[1];
  const label = args[2] || `imported_${Date.now()}`;

  if (!['eth', 'base', 'sol'].includes(chain)) return ctx.reply('❌ Supported chains: eth, base, sol');

  try {
    let address;
    if (chain === 'eth' || chain === 'base') {
      const w = new ethers.Wallet(privateKey);
      address = w.address;
    } else if (chain === 'sol') {
      const decoded = bs58.decode(privateKey);
      const kp = Keypair.fromSecretKey(decoded);
      address = kp.publicKey.toBase58();
    }

    const userId = ctx.from.id.toString();
    const wallets = loadWallets(userId);
    wallets.push({ id: `${label}_${Date.now()}`, label, chain, address, privateKey, createdAt: new Date().toISOString() });
    saveWallets(userId, wallets);

    // Delete user's message for security
    try { await ctx.deleteMessage(); } catch (_) {}

    await ctx.reply(`✅ *Wallet imported!*\n\nLabel: \`${label}\`\nChain: \`${chain.toUpperCase()}\`\nAddress: \`${address}\`\n\n🔐 Your message was deleted for security.`, { parse_mode: 'Markdown' });
  } catch (e) {
    ctx.reply('❌ Invalid private key.');
  }
};

// /wallets
const listWallets = async (ctx) => {
  const userId = ctx.from.id.toString();
  const wallets = loadWallets(userId);

  if (wallets.length === 0) return ctx.reply('No wallets yet.\n\nUse /genwallets or /addwallet to get started.');

  const chains = [...new Set(wallets.map(w => w.chain))];
  let msg = `💼 *Your Wallets (${wallets.length} total)*\n━━━━━━━━━━━━━━━\n\n`;

  chains.forEach(chain => {
    const chainWallets = wallets.filter(w => w.chain === chain);
    msg += `*${chain.toUpperCase()} (${chainWallets.length})*\n`;
    chainWallets.slice(0, 10).forEach(w => {
      msg += `• \`${w.label}\` — \`${w.address.slice(0, 8)}...${w.address.slice(-6)}\`\n`;
    });
    if (chainWallets.length > 10) msg += `_...and ${chainWallets.length - 10} more_\n`;
    msg += '\n';
  });

  await ctx.reply(msg, { parse_mode: 'Markdown' });
};

// /balance [chain]
const checkBalance = async (ctx) => {
  const args = ctx.message.text.split(' ').slice(1);
  const filterChain = args[0]?.toLowerCase();
  const userId = ctx.from.id.toString();
  const wallets = loadWallets(userId);

  if (wallets.length === 0) return ctx.reply('No wallets found. Use /genwallets or /addwallet first.');

  const filtered = filterChain ? wallets.filter(w => w.chain === filterChain) : wallets;
  if (filtered.length === 0) return ctx.reply(`No wallets found for chain: ${filterChain}`);

  await ctx.reply(`⏳ Checking balances for ${filtered.length} wallet(s)...`);

  const { getProvider } = require('../utils/providers');
  let msg = `💰 *Balances*\n━━━━━━━━━━━━━━━\n\n`;
  let totalByChain = {};

  for (const w of filtered) {
    try {
      let balance = '?';
      if (w.chain === 'eth' || w.chain === 'base') {
        const provider = getProvider(w.chain);
        const raw = await provider.getBalance(w.address);
        balance = parseFloat(ethers.formatEther(raw)).toFixed(4);
        totalByChain[w.chain] = (totalByChain[w.chain] || 0) + parseFloat(balance);
      } else if (w.chain === 'sol') {
        const { Connection, PublicKey, clusterApiUrl } = require('@solana/web3.js');
        const conn = new Connection(process.env.SOL_RPC || clusterApiUrl('mainnet-beta'));
        const lamports = await conn.getBalance(new PublicKey(w.address));
        balance = (lamports / 1e9).toFixed(4);
        totalByChain['sol'] = (totalByChain['sol'] || 0) + parseFloat(balance);
      }
      msg += `• \`${w.label}\` — *${balance}* ${w.chain.toUpperCase()}\n`;
    } catch (e) {
      msg += `• \`${w.label}\` — ⚠️ error\n`;
    }
  }

  msg += '\n*Totals:*\n';
  Object.entries(totalByChain).forEach(([chain, total]) => {
    msg += `${chain.toUpperCase()}: *${total.toFixed(4)}*\n`;
  });

  await ctx.reply(msg, { parse_mode: 'Markdown' });
};

// /fundwallets <chain> <amount_each>
const fundWallets = async (ctx) => {
  const args = ctx.message.text.split(' ').slice(1);
  if (args.length < 2) return ctx.reply('Usage: /fundwallets <chain> <amount_each>\nExample: /fundwallets eth 0.01');

  const chain = args[0].toLowerCase();
  const amountEach = parseFloat(args[1]);
  if (isNaN(amountEach) || amountEach <= 0) return ctx.reply('❌ Invalid amount.');

  const userId = ctx.from.id.toString();
  const wallets = loadWallets(userId);
  const targets = wallets.filter(w => w.chain === chain);

  if (targets.length === 0) return ctx.reply(`No ${chain.toUpperCase()} wallets found.`);

  // Find first wallet with most balance as sender
  // In practice user should designate a main wallet — for now we use first one
  await ctx.reply(
    `⚠️ *Fund Distribution*\n\nChain: \`${chain.toUpperCase()}\`\nAmount each: \`${amountEach}\`\nWallets to fund: \`${targets.length}\`\nTotal needed: \`${(amountEach * targets.length).toFixed(4)} ${chain.toUpperCase()}\`\n\nReply with your *sender private key* to proceed, or /cancel to abort.`,
    { parse_mode: 'Markdown' }
  );

  // Store pending state (simplified — full session handling in next module)
  global.pendingFund = global.pendingFund || {};
  global.pendingFund[userId] = { chain, amountEach, targets };
};

module.exports = { genWallets, addWallet, listWallets, checkBalance, fundWallets };
