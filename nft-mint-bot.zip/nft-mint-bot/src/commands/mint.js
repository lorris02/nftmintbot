const { ethers } = require('ethers');
const { Keypair, Transaction, Connection, clusterApiUrl } = require('@solana/web3.js');
const bs58 = require('bs58');
const { getProvider } = require('../utils/providers');
const fs = require('fs');
const path = require('path');

const { DATA_ROOT: WALLETS_DIR } = require('../utils/storage');
const loadWallets = (userId) => {
  const file = path.join(WALLETS_DIR, `${userId}.json`);
  if (!fs.existsSync(file)) return [];
  return JSON.parse(fs.readFileSync(file, 'utf8'));
};

// Scheduled mints store
global.scheduledMints = global.scheduledMints || {};

// Standard ERC721/ERC1155 mint ABI
const MINT_ABI = [
  'function mint(uint256 quantity) payable',
  'function mint(address to, uint256 quantity) payable',
  'function publicMint(uint256 quantity) payable',
  'function safeMint(address to) payable',
];

const executeMint = async (wallet, contractAddress, chain, quantity, gasLimit, maxGasGwei) => {
  const provider = getProvider(chain);
  const signer = new ethers.Wallet(wallet.privateKey, provider);
  const contract = new ethers.Contract(contractAddress, MINT_ABI, signer);

  const feeData = await provider.getFeeData();
  const maxFeePerGas = maxGasGwei
    ? ethers.parseUnits(maxGasGwei.toString(), 'gwei')
    : feeData.maxFeePerGas;

  // Try different mint function signatures
  const mintFunctions = ['mint', 'publicMint', 'safeMint'];
  let tx;

  for (const fn of mintFunctions) {
    try {
      if (fn === 'safeMint') {
        tx = await contract[fn](wallet.address, {
          gasLimit: gasLimit || 300000,
          maxFeePerGas,
        });
      } else {
        tx = await contract[fn](quantity, {
          gasLimit: gasLimit || 300000,
          maxFeePerGas,
        });
      }
      break;
    } catch (e) {
      continue;
    }
  }

  if (!tx) throw new Error('No valid mint function found on contract');
  return tx;
};

// /mint <chain> <contract> <quantity> [maxGasGwei] [walletLabel]
const manualMint = async (ctx) => {
  const args = ctx.message.text.split(' ').slice(1);
  if (args.length < 3) {
    return ctx.reply(
      '📋 *Usage:*\n`/mint <chain> <contract> <quantity> [maxGasGwei] [walletLabel]`\n\n*Example:*\n`/mint eth 0xabc...123 1 30 mywallet`',
      { parse_mode: 'Markdown' }
    );
  }

  const [chain, contractAddress, quantityStr, maxGasGwei, walletLabel] = args;
  const quantity = parseInt(quantityStr) || 1;
  const userId = ctx.from.id.toString();
  const wallets = loadWallets(userId);

  const wallet = walletLabel
    ? wallets.find(w => w.label === walletLabel && w.chain === chain)
    : wallets.find(w => w.chain === chain);

  if (!wallet) return ctx.reply(`❌ No ${chain.toUpperCase()} wallet found${walletLabel ? ` with label "${walletLabel}"` : ''}.`);

  await ctx.reply(`⏳ Minting *${quantity}x* on \`${contractAddress.slice(0, 8)}...\` with wallet \`${wallet.label}\`...`, { parse_mode: 'Markdown' });

  try {
    const tx = await executeMint(wallet, contractAddress, chain, quantity, null, maxGasGwei ? parseFloat(maxGasGwei) : null);
    await ctx.reply(
      `✅ *Mint TX sent!*\n\nWallet: \`${wallet.label}\`\nTX: \`${tx.hash}\`\n\n⏳ Waiting for confirmation...`,
      { parse_mode: 'Markdown' }
    );
    const receipt = await tx.wait();
    await ctx.reply(`🎉 *Confirmed!* Block: \`${receipt.blockNumber}\``, { parse_mode: 'Markdown' });
  } catch (e) {
    await ctx.reply(`❌ Mint failed: ${e.message}`);
  }
};

// /batchmint <chain> <contract> <quantity_each> [maxGasGwei]
const batchMint = async (ctx) => {
  const args = ctx.message.text.split(' ').slice(1);
  if (args.length < 3) {
    return ctx.reply(
      '📋 *Usage:*\n`/batchmint <chain> <contract> <quantity_each> [maxGasGwei]`\n\n*Example:*\n`/batchmint eth 0xabc...123 1 30`',
      { parse_mode: 'Markdown' }
    );
  }

  const [chain, contractAddress, quantityStr, maxGasGwei] = args;
  const quantity = parseInt(quantityStr) || 1;
  const userId = ctx.from.id.toString();
  const wallets = loadWallets(userId).filter(w => w.chain === chain);

  if (wallets.length === 0) return ctx.reply(`❌ No ${chain.toUpperCase()} wallets found.`);

  await ctx.reply(`🔁 *Batch Mint Starting*\n\nContract: \`${contractAddress.slice(0, 8)}...\`\nWallets: \`${wallets.length}\`\nQty each: \`${quantity}\`\n\n⏳ Firing all wallets simultaneously...`, { parse_mode: 'Markdown' });

  const results = await Promise.allSettled(
    wallets.map(w => executeMint(w, contractAddress, chain, quantity, null, maxGasGwei ? parseFloat(maxGasGwei) : null))
  );

  let success = 0, failed = 0;
  let report = `📊 *Batch Mint Report*\n━━━━━━━━━━━━━━━\n\n`;

  results.forEach((result, i) => {
    const w = wallets[i];
    if (result.status === 'fulfilled') {
      success++;
      report += `✅ \`${w.label}\` — \`${result.value.hash.slice(0, 12)}...\`\n`;
    } else {
      failed++;
      report += `❌ \`${w.label}\` — ${result.reason?.message?.slice(0, 40)}\n`;
    }
  });

  report += `\n✅ Success: *${success}* | ❌ Failed: *${failed}*`;
  await ctx.reply(report, { parse_mode: 'Markdown' });
};

// /schedulemint <chain> <contract> <quantity> <datetime> [maxGasGwei]
// datetime format: YYYY-MM-DD HH:MM (UTC)
const scheduleMint = async (ctx) => {
  const args = ctx.message.text.split(' ').slice(1);
  if (args.length < 4) {
    return ctx.reply(
      '📋 *Usage:*\n`/schedulemint <chain> <contract> <quantity> <YYYY-MM-DD> <HH:MM> [maxGasGwei]`\n\n*Example:*\n`/schedulemint eth 0xabc...123 1 2025-01-20 15:00 30`',
      { parse_mode: 'Markdown' }
    );
  }

  const chain = args[0];
  const contractAddress = args[1];
  const quantity = parseInt(args[2]) || 1;
  const dateStr = args[3];
  const timeStr = args[4];
  const maxGasGwei = args[5] ? parseFloat(args[5]) : null;

  const mintTime = new Date(`${dateStr}T${timeStr}:00Z`);
  if (isNaN(mintTime.getTime())) return ctx.reply('❌ Invalid date/time format. Use: YYYY-MM-DD HH:MM');

  const now = Date.now();
  const delay = mintTime.getTime() - now;
  if (delay <= 0) return ctx.reply('❌ That time is in the past.');

  const userId = ctx.from.id.toString();
  const wallets = loadWallets(userId).filter(w => w.chain === chain);
  if (wallets.length === 0) return ctx.reply(`❌ No ${chain.toUpperCase()} wallets found.`);

  const scheduleId = `${userId}_${Date.now()}`;
  await ctx.reply(
    `⏰ *Mint Scheduled!*\n\nContract: \`${contractAddress.slice(0, 8)}...\`\nChain: \`${chain.toUpperCase()}\`\nTime: \`${dateStr} ${timeStr} UTC\`\nWallets: \`${wallets.length}\`\nQty each: \`${quantity}\`\nID: \`${scheduleId}\`\n\nUse /status to view or /cancel to remove.`,
    { parse_mode: 'Markdown' }
  );

  const timeout = setTimeout(async () => {
    await ctx.reply(`🚀 *Scheduled mint firing now!*\n\nContract: \`${contractAddress.slice(0, 8)}...\``, { parse_mode: 'Markdown' });

    const results = await Promise.allSettled(
      wallets.map(w => executeMint(w, contractAddress, chain, quantity, null, maxGasGwei))
    );

    let success = 0, failed = 0;
    results.forEach(r => r.status === 'fulfilled' ? success++ : failed++);
    await ctx.reply(`🎯 *Scheduled Mint Done*\n✅ ${success} success | ❌ ${failed} failed`, { parse_mode: 'Markdown' });
    delete global.scheduledMints[scheduleId];
  }, delay);

  global.scheduledMints[scheduleId] = { timeout, contractAddress, chain, quantity, mintTime, userId };
};

module.exports = { manualMint, batchMint, scheduleMint };
