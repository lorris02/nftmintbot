const { Markup } = require('telegraf');

module.exports = async (ctx) => {
  const username = ctx.from.first_name || 'fren';

  const welcome = `
🚀 *NFT Mint Bot*
━━━━━━━━━━━━━━━━

Gm ${username}! Ready to mint.

*Supported Chains:*
• Ethereum (ETH)
• Base (BASE)
• Solana (SOL)
• _(more coming)_

*Quick Start:*
1️⃣ Generate or import wallets
2️⃣ Fund them with gas
3️⃣ Set up a monitor or mint directly

Use the menu below or type any command.
  `;

  await ctx.reply(welcome, {
    parse_mode: 'Markdown',
    ...Markup.keyboard([
      ['💼 /wallets', '⚙️ /genwallets'],
      ['💰 /balance', '⛽ /gas'],
      ['🎯 /mint', '🔁 /batchmint'],
      ['👀 /monitor', '📊 /status'],
      ['🌊 /floor', '❌ /cancel'],
    ]).resize()
  });
};
